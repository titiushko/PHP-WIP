Meris Theme
================

Meris is a free WordPress theme that can be use for various purposes, for business, travel, food, service and more. The clean homepage layout is very flexible due to it allows to add widgets. Meris theme comes with full-width sliders in the homepage and small featured sliders in the sidebar(optional), portfolios, social icons, slogon, and other popular widgets. More options are given to the sidebar setting: no sidebar, left sidebar, right sidebar, and sidebar on both sides. Furthermore, Font Awesome Icons are avaible in the theme to add icons aywhere. This theme is built with the latest HTML5 and CSS3 website standard (from the Twitter Bootstrap), and fully responsive in different browsers and displays. Meris is the ideal theme to create your personal websites and business websites for company.


## Copyrights for Resources used in this theme.

The theme itself is nothing but 100% GPL v2 or later.


Icon
 * License: The icons are free for personal use and also free for commercial use.
 * All icons are under GPL v3 have been created by our team.
 * Copyright: Mageewp.com, http://www.mageewp.com

--------------------------------------------------------------------------------------------

Font 
 ==Font Awesome 4.1.0
 * License: License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 * Copyright: by @davegandy - http://fontawesome.io - @fontawesome
--------------------------------------------------------------------------------------------

Images
 * License: Background images and home page images are from Unsplash with "do whatever you want" license. 
 * Copyright: http://unsplash.com/

--------------------------------------------------------------------------------------------

Administration Panel 
 * License: For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. 
 * Copyright: Devin Price, http://wptheming.com/options-framework-plugin/ 

--------------------------------------------------------------------------------------------

JS files

 ==bootstrap.min.js
 * Bootstrap v3.0.3 (http://getbootstrap.com)
 * Copyright 2013 Twitter, Inc.
 * Licensed under http://www.apache.org/licenses/LICENSE-2.0

 ==less.min.js
 * LESS - Leaner CSS v1.4.2
 * http://lesscss.org
 *
 * Copyright (c) 2009-2013, Alexis Sellier
 * Licensed under the Apache 2.0 License.

 ==meris.js
 * License: GPLv3
 * Copyright: MageeWp, http://www.mageewp.com

 ==html5.js
 * HTML5 Shiv v3.7.0 | @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed

 == Respond.js
 *! Respond.js v1.4.2: min/max-width media query polyfill
 * Copyright 2014 Scott Jehl
 * Licensed under MIT
 * http://j.mp/respondjs */
--------------------------------------------------------------------------------------------

	For any help you can mail me at support[at]mageewp.com

/**********************************************************/

