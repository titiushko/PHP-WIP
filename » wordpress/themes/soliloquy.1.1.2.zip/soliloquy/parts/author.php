<div class="author">
    <?php 
    _e('By ', 'nimbus'); 
    the_author_posts_link();
    ?>
</div>
