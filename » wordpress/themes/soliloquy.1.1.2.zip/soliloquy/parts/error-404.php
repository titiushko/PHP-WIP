<div class='container text-center'>
    <h1><?php _e('404', 'nimbus'); ?></h1>
    <h2 class="text-center"><?php _e('The page you are looking for is not availible.', 'nimbus'); ?></h2>
</div>