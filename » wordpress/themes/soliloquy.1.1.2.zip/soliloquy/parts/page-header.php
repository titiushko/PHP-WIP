<?php
n_clear(25);
?>
<h2 class="post_title">
    <?php
    get_template_part( 'parts/title', 'page');
    ?>
</h2>
<?php
get_template_part( 'parts/image', '1170_640');
get_template_part( 'parts/image', 'caption');
?>
<div class="clear30"></div>