<div class="container">
    <p class="text-center" style="margin: 5px auto;"><?php _e('No content matched your request.', 'nimbus'); ?></p>
</div>
