<?php
get_header();
get_template_part( 'parts/loop');
get_footer(); 
?>