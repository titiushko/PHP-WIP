

### 1.7.4 - 16/07/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version
 * Update style.css
