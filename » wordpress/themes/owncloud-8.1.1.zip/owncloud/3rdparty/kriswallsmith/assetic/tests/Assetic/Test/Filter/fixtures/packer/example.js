/**
 * Example function
 */
var exampleFunction = function(arg1, arg2) {
    // Some comment...
    alert('exampleFunction called!');
}