<?php
/**
 * The Sidebar containing the footer left widget area.
 *
 * @package thbusiness
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php if ( ! dynamic_sidebar( 'footer-left' ) ) : ?>

		<?php endif; // end sidebar widget area ?>
	</div><!-- #secondary -->
