If you are interested in translating your theme, use default.po as a template to create a po file for the new translation file.

The resulting translated file should be named with the following format:



- ISO 639 language code (lowercase)

- an underscore

- ISO 3166-1 alpha-2 country code (uppercase) 

- .mo



So for an Italian translation, the file name would be it_IT.po


Please send the translated file to: support@yithemes.com

Thanks!