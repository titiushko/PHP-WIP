<?php

return array(
    'slug' => 'celestino',
    'url' => 'https://yithemes.com/themes/wordpress/celestino-clean-and-creative-portfolio-theme/?utm_source=yith-panel&utm_medium=wpadmin&utm_content=banner-upgrade-celestino&utm_campaign=yith-admin',

    //'price' => ''   // default price, if any response from remote
    //'img' => YIT_CORE_URL .'/assets/images/buy-premium.png'   // banner image
);
