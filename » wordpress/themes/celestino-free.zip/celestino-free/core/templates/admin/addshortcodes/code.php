<div class="fieldset">
	<p><?php _e('This is a special shortcode. Insert shortcode for configure it.', 'yit') ?></p>
	<input type="hidden" id="code-<?php echo $var[1]; ?>" name="code-<?php echo $var[1]; ?>" value='<?php echo $var[0]; ?>' />
</div>