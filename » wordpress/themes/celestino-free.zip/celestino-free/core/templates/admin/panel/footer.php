<?php
/**
 * The footer of the panel. 
 * 
 * @package WordPress
 * @subpackage Your Inspiration Themes
 */
?>

    </div>
    <div class="submit_footer">
            <span class="submit bottom">
                <input type="submit" value="<?php _e('Save options', 'yit') ?>" />
            </span>
    </div>
    </form>
</div>