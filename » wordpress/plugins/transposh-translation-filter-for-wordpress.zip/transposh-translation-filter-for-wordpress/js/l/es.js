/*
 * Transposh v0.9.3
 * http://transposh.org/
 *
 * Copyright 2013, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Mon, 06 May 2013 02:15:55 +0300
 */
t_jp.l={"Close without saving?":"Cerrar sin guardar?","You have made a change to the translation. Are you sure you want to discard it?":"Has cambiado la traducion. Estas seguro que lo quieres eliminar?",History:"Historia","Loading...":"Cargando...",Translated:"Traducido",By:"Por",At:"En",google:"google",bing:"bing",apertium:"apertium","manual translation":"traducci\u00f3n manual","bing suggest":"sugerencia de bing","google suggest":"sugerencia de google","apertium suggest":"sugerencia de apertium",
"Edit Translation":"Editar traducci\u00f3n","Original text":"Texto original","read alternate translations":"lee traducci\u00f3nes alternativas","previous translation":"traducci\u00f3n anterior","find on page":"encuentra en la pagina","next translation":"siguiente traducci\u00f3n","Translate to":"Traducir a","view translation log":"muestra diario de traducion","virtual keyboard":"teclado virtual","approve translation":"aprueba traducion","delete":"eliminar",Discard:"Descartar",Cancel:"Cancelar"};
