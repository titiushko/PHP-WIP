/*
 * Transposh v0.9.3
 * http://transposh.org/
 *
 * Copyright 2013, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Mon, 06 May 2013 02:15:55 +0300
 */
t_jp.l={"Close without saving?":"Chiudere senza salvare?","You have made a change to the translation. Are you sure you want to discard it?":"&Egrave; stata fatta una modifica alla traduzione. Si &egrave; sicuri di volerla scartare?",History:"Storia","Loading...":"Caricamento...",Translated:"Tradotto",By:"Da",At:"A",google:"google",bing:"bing",apertium:"apertium","manual translation":"traduzione manuale","bing suggest":"bing suggerisce","google suggest":"google suggerisce","apertium suggest":"apertium suggerisce",
"Edit Translation":"Modifica Traduzione","Original text":"Testo Originale","read alternate translations":"leggi le traduzioni alternative","previous translation":"traduzione precedente","find on page":"trova nella pagina","next translation":"prossima traduzione","Translate to":"Tradotto in","view translation log":"guarda il log delle traduzioni","virtual keyboard":"tastiera virtuale","approve translation":"approva traduzione","delete":"cancella",Discard:"Scarta",Cancel:"Cancella"};
