<?php

/*
 * Transposh v0.9.3
 * http://transposh.org/
 *
 * Copyright 2013, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Mon, 06 May 2013 02:15:55 +0300
 */

/*
 * This file handles various AJAX needs of our plugin
 */

echo "This file was removed in 0.8.0 and is only kept for debugging";

?>